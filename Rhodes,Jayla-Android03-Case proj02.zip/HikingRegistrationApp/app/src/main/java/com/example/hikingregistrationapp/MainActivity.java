package com.example.hikingregistrationapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity {
    double costPerTicket= 16.99;
    int numberOfTickets;
    double totalCost;
    String groupChoice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        final EditText tickets= (EditText)findViewById(R.id.tvTickets);
        final Spinner group= (Spinner)findViewById(R.id.spLocation);
        Button cost = (Button)findViewById(R.id.btCost);
        cost.setOnClickListener(new View.OnClickListener() {
            final TextView result=((TextView)findViewById(R.id.tvResult));
            @Override
            public void onClick(View view) {
                numberOfTickets= Integer.parseInt(tickets.getText().toString());
                totalCost=costPerTicket*numberOfTickets;
                DecimalFormat currency= new DecimalFormat("$###,###.##");
                groupChoice=group.getSelectedItem().toString();
                result.setText(" Cost for "+groupChoice+" is "+currency.format(totalCost));
            }
        });
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}